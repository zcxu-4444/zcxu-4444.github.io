# Author   : Zhuoran Catherine Xu
# Email    : zcxu@umass.edu
# Spire ID : 34411005

order1 = ('manan', 'holyoke', 'FLAT3', 'chicken', 'white', 'pinto', False, 'queso blanco', 'cheese', 'fajita veggies', 'sour cream')
order2 = ('allison', 'greenfield', 'MAGIC', 'carnitas', 'brown', 'black', True, 'cheese', 'fajita veggies', 'sour cream', 'guacamole', 'tomato salsa')
order3 = ('Dhsjvwd Bvyfnuve', 'holyoke', 'MAGIC', 'veggies', 'brown', 'pinto', True, 'fajita veggies', 'sour cream', 'queso blanco', 'tomato salsa', 'guacamole', 'chili corn salsa', 'cheese', 'tomatillo green chili salsa')

def get_protein(order):
    if 'chicken' in order:
        return 2.5
    elif 'steak' in order:
        return 3.5
    elif 'barbacoa' in order:
        return 3.5
    elif 'carnitas' in order:
        return 3
    elif 'veggies' in order:
        return 2.5
    else:
        return 0

def get_rice(order):
    if 'white' in order:
        return 2.5
    elif 'brown' in order:
        return 3.5
    else:
        return 0

def get_beans(order):
    if 'black' in order:
        return 2.5
    elif 'pinto' in order:
        return 2.5
    else:
        return 0
    
def get_burrito(order):
    if True in order:
        return 2
    elif False in order:
        return 0
    else:
        return 0

def get_toppings(order):
    total = 0
    for topping in order:
        if topping == 'guacamole' and order[3] != 'veggies':
            total += 2.75
        elif topping == 'tomato salsa':
            total += 2.5
        elif topping == 'chili corn salsa':
            total += 1.75
        elif topping == 'tomatillo green chili salsa':
            total += 2.0
        elif topping == 'sour cream':
            total += 2.5
        elif topping == 'fajita veggies' and (order[3] != 'veggies'):
            total += 2.5
        elif topping == 'cheese':
            total += 2
        elif topping == 'queso blanco':
            total += 2.75
        else:
            total += 0
    return total
print(get_toppings(order3))

def apply_discount(order, total):
    if 'MAGIC' in order:
        return total * 0.95
    elif 'SUNDAYFUNDAY' in order:
        return total * 0.9
    elif 'FLAT3' in order:
        return total - 3
    else:
        return total

def approximate_time(order):
    if 'amherst' in order:
        return 15
    elif 'north amherst' in order:
        return 15
    elif 'south amherst' in order:
        return 15
    elif 'hadley' in order:
        return 15
    elif 'northampton' in order:
        return 30
    elif 'south hadley' in order:
        return 30
    elif 'belchertown' in order:
        return 30
    elif 'sunderland' in order:
        return 30
    elif 'holyoke' in order:
        return 45
    elif 'greenfield' in order:
        return 45
    elif 'deerfield' in order:
        return 45
    elif 'springfield' in order:
        return 45
    else:
        return None

def generate_invoice(order):
    toppings = [topping for topping in order[7:] if topping is not None]
    def burrito_fix(order):
        if order[6] == True:
            return 'Yes'
        else:
            return 'No'
    print(f'Welcome to Chipotle Mexican Grill Hadley, {order[0]}.')
    print('Your invoice is displayed below:')
    print(f'Protein: {order[3]} - ${get_protein(order)}')
    print(f'Rice: {order[4]} rice - ${get_rice(order)}')
    print(f'Beans: {order[5]} beans - ${get_beans(order)}')
    print(f'Burrito: {burrito_fix(order)} - ${get_burrito(order)}')
    print(f'Toppings: {", ".join(toppings)} - ${get_toppings(order)}')
    print(f'Subtotal: ${get_protein(order) + get_rice(order) + get_beans(order) + get_burrito(order) + get_toppings(order)}')
    print(f'Discount Code: {order[2]}')
    print(f'Total: ${apply_discount(order, get_protein(order) + get_rice(order) + get_beans(order) + get_burrito(order) + get_toppings(order))}')
    print(f'You Save: ${(get_protein(order) + get_rice(order) + get_beans(order) + get_burrito(order) + get_toppings(order)) - apply_discount(order, get_protein(order) + get_rice(order) + get_beans(order) + get_burrito(order) + get_toppings(order))}')
    print(f'Your order will be ready in {approximate_time(order)} minutes.')
    print('Enjoy your meal and have a good day!')

generate_invoice(order3)