# Author   : Zhuoran Catherine Xu
# Email    : zcxu@umass.edu
# Spire ID : 34411005

def get_guess():
    word = input("What word is this?: ")
    word = word[:5].upper()
    return word

def print_word(word):
    print(' '.join(word))

def exact_match_compare(solution, guess):
    result = ""
    for i in range(len(solution)):
        if solution[i] == guess[i]:
            result += "🟢"
        else:
            result += "🔴"
    return result

def one_turn(solution):
    guess = get_guess()
    guessed_word = print_word(guess)
    if exact_match_compare(solution, guess) == "🟢🟢🟢🟢🟢":
        print("🟢🟢🟢🟢🟢")
        print("Congratulations")
        exit()
    else:
        print(exact_match_compare(solution, guess))

import random
def make_solution():
    solutions = ["WHICH", "THEIR", "THERE", "WOULD", "OTHER", "THESE", "ABOUT", "FIRST", "COULD", "AFTER"]
    return random.choice(solutions)

soln = make_solution()
one_turn(soln)
one_turn(soln)
one_turn(soln)
one_turn(soln)
one_turn(soln)
one_turn(soln)
print(f"Word was \"{soln}\", better luck next time.")